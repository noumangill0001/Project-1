let burgar = document.querySelector('.ham-burgar');
let navbar = document.querySelector('.navbar');
let logos = document.querySelector('.logos');
let navbarListItems = document.querySelector('.navbar-list-items');
let rightNav = document.querySelector('.right-nav-item');

burgar.addEventListener("click", (e)=>{
    rightNav.classList.toggle('v-class');
    logos.classList.toggle('v-class');
    navbarListItems.classList.toggle('v-class');
    navbar.classList.toggle('h-nav-resp');
})

// Form Validation :
function validation(){
    let user = document.getElementById('username').value;
    let email = document.getElementById('email').value;
    let password = document.getElementById('password').value;
    let conpassword = document.getElementById('confirm_password').value;
    let phone = document.getElementById('phone').value;

    if (user == "") {
        document.getElementById("username").style.cssText = "border: 3px solid red;";
        return false;
    }
    else if (user.length <= 2 || user.length > 20) {
        document.getElementById("username").style.cssText = "border: 3px solid red;";
        return false;
    }
    else if (!isNaN(user)) {
        document.getElementById("username").style.cssText = "border: 3px solid red;";
        return false;
    }
    else{
        document.getElementById("username").style.cssText = "border: 3px solid green;";
    }

    if (email == "") {
        document.getElementById("email").style.cssText = "border: 3px solid red;";
        return false;
    }
    else if (email.indexOf('@') <= 0) {
        document.getElementById("email").style.cssText = "border: 3px solid red;";
        return false;
    }
    else if ((email.charAt(email.length - 4) != '.') && (email.length - 3) != '.') {
        document.getElementById("email").style.cssText = "border: 3px solid red;";
        return false;
    }
    else{
        document.getElementById("email").style.cssText = "border: 3px solid green;";
    }

    if (password == "") {
        document.getElementById("password").style.cssText = "border: 3px solid red;";
        return false;
    }
    else if (password.length <= 5 || password.length > 15) {
        document.getElementById("password").style.cssText = "border: 3px solid red;";
        return false;
    }
    else{
        document.getElementById("password").style.cssText = "border: 3px solid green;";
    }
   
    if (conpassword == "") {
        document.getElementById("confirm_password").style.cssText = "border: 3px solid red;";
        return false;
    }
    else if (password != conpassword) {
        document.getElementById("confirm_password").style.cssText = "border: 3px solid red;";
        return false;
    }
    else{
        document.getElementById("confirm_password").style.cssText = "border: 3px solid green;";
    }

    if (phone == "") {
        document.getElementById("phone").style.cssText = "border: 3px solid red;";
        return false;
    }
    else if (isNaN(phone)) {
        document.getElementById("phone").style.cssText = "border: 3px solid red;";
        return false;
    }
    else if (phone.length != 14) {
        document.getElementById("phone").style.cssText = "border: 3px solid red;";
        return false;
    }
}